<template>
  <div>
    <h2>유저 목록</h2>
    <table border="1">
      <thead>
        <tr>
          <th>ID</th><th>PW</th><th>이름</th><th>이메일</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.pw }}</td>
          <td>{{ user.name }}</td>
          <td>{{ user.email }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
const users = ref([]);
onMounted(async () => {
  const res = await fetch('http://localhost:8080/api/users');
  users.value = await res.json();
});
</script>
