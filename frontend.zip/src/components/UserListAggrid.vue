<template>
  <div class="ag-theme-alpine" style="width:1000px;height:400px;">
    <ag-grid-vue
      :columnDefs="columnDefs"
      :rowData="rowData"
      :defaultColDef="defaultColDef"
      :domLayout="'autoHeight'"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { AgGridVue } from 'ag-grid-vue3'

const columnDefs = [
  { headerName: "ID", field: "id", sortable: true, filter: true },
  { headerName: "PW", field: "pw" },
  { headerName: "이름", field: "name", sortable: true, filter: true },
  { headerName: "이메일", field: "email", sortable: true, filter: true }
]
const rowData = ref([])
const defaultColDef = { resizable: true }

onMounted(async () => {
  const res = await fetch('http://localhost:8080/api/users')
  rowData.value = await res.json()
})
</script>

