<template>
  <UserList />
</template>
<script setup>
import UserList from './components/UserListAggrid.vue'
</script>